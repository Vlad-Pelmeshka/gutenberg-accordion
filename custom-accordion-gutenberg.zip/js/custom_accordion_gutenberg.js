const { registerBlockType } = wp.blocks;

const {
	RichText,
	InspectorControls,
	InnerBlocks
 } = wp.blockEditor;

const {
	PanelBody,
	IconButton
} = wp.components;

const ALLOWED_BLOCKS = ['accordion-plugin/accordion-plugin-item'];
const PARAGRAPH_BLOCKS = ['core/paragraph'];


registerBlockType('accordion-plugin/accordion-plugin-block',{
	title: 		'Accordion Plugin Block',
	description:'Generate a accordion block',
	icon: 		'editor-ul',
	category: 	'design',

	edit: () => {

		return ([
			React.createElement("div", {
			  		className: 		 "plugin_accordion"
				},
				React.createElement(InnerBlocks, {
					allowedBlocks: ALLOWED_BLOCKS
				})
			)
		]);
	},
	save: () => {

		return (

			React.createElement("div", {
			  		className: 	"plugin_accordion",
			  		role: 		"tablist"
				},
				React.createElement(InnerBlocks.Content, null)
			)
		);
	}

});



registerBlockType('accordion-plugin/accordion-plugin-item',{
	title: 		'Accordion Plugin Item',
	description:'Generate a accordion item',
	parent: 	[ 'vlad/vlad-gutenberg-block' ],

	attributes:{
		title: {
			type: 	  'string',
			source:   'html',
			selector: 'h3'
		},
		body: {
			type: 	  'string',
			source:   'html',
			selector: 'p'
		}
	},


	edit: ({ attributes, setAttributes}) => {


		const {
			title,
			body
		} = attributes;

		function onChangeTitle(newTitle){
	    	setAttributes( { title: newTitle  });
	    }
	    function onChangeBody(newBody){
	    	setAttributes( { body: newBody  });
	    }

		return ([
			React.createElement("div", {
					className: "accordion-item"
				},
				React.createElement("div", {
				  		className: "accordion-title"
					},
					React.createElement(RichText, {
						key: 		 "editable",
						tagName: 	 "h3",
						placeholder: "Your title",
						value: 		 attributes.title,
						onChange: 	 onChangeTitle
					})
				),
				React.createElement("div", {
				  		className: "accordion-description"
					},
					React.createElement(RichText, {
						key: 		 "editable",
						tagName: 	 "p",
						placeholder: "Your description",
						value: 		 attributes.body,
						onChange: 	 onChangeBody
					})
				)
			)
		]);
	},
	save:  ({ attributes }) => {

		const {
			title,
			titleColor,
			body
		} = attributes;

		return (

			React.createElement("div", {
  					className: 	"accordion-item"
				},
				React.createElement("div", {
  						className: "accordion-title-block"
					},
					React.createElement("div", {
  							className: "accordion-number"
						},
						"01"
					),
					React.createElement("div", {
  							className: 	"accordion-title",
  							role: 	  	"tab"
						},
						React.createElement(RichText.Content, {
								tagName:"h3",
								value: 	title
							}
						)
					),
					React.createElement("div", {
  							className: "close"
						}
					)
				),
				React.createElement("div", {
  						className: "accordion-description"
					},
					React.createElement(RichText.Content, {
							tagName: 	 "p",
							value: 		 body,
						}
					)
				)
			)
		);
	}

});
