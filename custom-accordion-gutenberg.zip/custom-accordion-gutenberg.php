<?php
/**
 * 	Plugin Name: Custom accordion gutenberg
 * 	Description:  Custom accordion gutenberg block for task
 *	Version: 1.0.0
 *	Author: Vlad
 */


function custom_accordion_gutenberg_register()
{
	wp_register_script( 'accordion_gutenberg-js', plugin_dir_url(__FILE__) . 'js/custom_accordion_gutenberg.js', array('wp-blocks', 'wp-editor', 'wp-components' ));

	wp_register_style( 'accordion_gutenberg-css', plugin_dir_url(__FILE__) . 'css/custom-accordion-gutenberg.css', array());
	wp_register_style( 'accordion_gutenberg-view-css', plugin_dir_url(__FILE__) . 'css/custom-accordion-gutenberg-view.css', array());

	register_block_type( 'accordion-plugin/accordion-plugin-block', array(
		'editor_script' => 'accordion_gutenberg-js',
		'editor_style' 	=> 'accordion_gutenberg-css',
		'style' 		=> 'accordion_gutenberg-view-css'
	) );


	wp_enqueue_script( 'accordion_gutenberg_view-js',plugin_dir_url(__FILE__) . 'js/custom-accordion-gutenberg-view.js', array(),null, true);
}

add_action( 'init', 'custom_accordion_gutenberg_register' );
